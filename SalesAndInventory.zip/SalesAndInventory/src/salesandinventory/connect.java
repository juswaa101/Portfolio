/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package salesandinventory;
import java.sql.*;
/**
 *
 * @author Joshua
 */
public class connect {
    public static Connection con;
    public static String dbFile = "C:\\Users\\joshu\\OneDrive\\Documents\\NetBeansProjects\\SalesAndInventory\\assets\\Product.accdb";
    public static String dbUrl = "jdbc:ucanaccess://" +dbFile.trim()+";memory=true";
    public static Connection getConnection(){
        try{
            con = DriverManager.getConnection(dbUrl, "", "");
        }catch(Exception ex){
            System.out.println(""+ex);
        }
        return con;
    }
}
